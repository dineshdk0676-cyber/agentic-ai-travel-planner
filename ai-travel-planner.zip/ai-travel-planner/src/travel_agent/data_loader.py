"""Load and validate the JSON datasets (flights, hotels, places)."""

import json
from functools import lru_cache

from .config import CITY_ALIASES, CITY_COORDINATES, DATA_DIR

REQUIRED_FIELDS = {
    "flights.json": {"flight_id", "airline", "from", "to", "departure_time", "arrival_time", "price"},
    "hotels.json": {"hotel_id", "name", "city", "stars", "price_per_night", "amenities"},
    "places.json": {"place_id", "name", "city", "type", "rating"},
}


@lru_cache(maxsize=None)
def _load_json(file_name: str) -> tuple[dict, ...]:
    """Read a dataset once, validate its fields and return it as an immutable tuple."""
    path = DATA_DIR / file_name
    try:
        with path.open(encoding="utf-8") as handle:
            records = json.load(handle)
    except FileNotFoundError as exc:
        raise FileNotFoundError(f"Dataset not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"Dataset {file_name} is not valid JSON: {exc}") from exc

    required = REQUIRED_FIELDS[file_name]
    for index, record in enumerate(records):
        missing = required - record.keys()
        if missing:
            raise ValueError(f"{file_name} record #{index} is missing fields: {sorted(missing)}")
    return tuple(records)


def load_flights() -> list[dict]:
    """Return all flight records."""
    return list(_load_json("flights.json"))


def load_hotels() -> list[dict]:
    """Return all hotel records."""
    return list(_load_json("hotels.json"))


def load_places() -> list[dict]:
    """Return all place / attraction records."""
    return list(_load_json("places.json"))


def resolve_city(name: str | None) -> str | None:
    """Map free-text user input to a canonical city name, or None if unknown."""
    if not name:
        return None
    key = name.strip().lower()
    if key in CITY_ALIASES:
        return CITY_ALIASES[key]
    for city in CITY_COORDINATES:
        if city.lower() == key:
            return city
    return None


def available_cities() -> list[str]:
    """Cities that exist in the hotel/places data and have coordinates."""
    return sorted(CITY_COORDINATES)


def available_routes() -> list[tuple[str, str]]:
    """All (origin, destination) pairs that have at least one flight."""
    return sorted({(f["from"], f["to"]) for f in load_flights()})
