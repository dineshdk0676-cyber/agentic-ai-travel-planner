"""Pure business logic over the datasets (no LangChain dependency).

Each function returns a plain, JSON-serialisable ``dict`` so it can be used by
the LangChain tools, the offline planner and the unit tests alike.
"""

import math
from datetime import datetime

from .config import DEFAULT_DAILY_EXPENSE_INR
from .data_loader import load_flights, load_hotels, load_places, resolve_city

FLIGHT_SORTS = ("cheapest", "fastest", "earliest")
HOTEL_SORTS = ("best_value", "cheapest", "highest_rated")


# --------------------------------------------------------------------------- flights
def _enrich_flight(flight: dict) -> dict:
    """Add a computed duration to a raw flight record."""
    departure = datetime.fromisoformat(flight["departure_time"])
    arrival = datetime.fromisoformat(flight["arrival_time"])
    minutes = int((arrival - departure).total_seconds() // 60)
    return {**flight, "duration_minutes": minutes, "duration_hours": round(minutes / 60, 1)}


def search_flights(
    origin: str,
    destination: str,
    date: str | None = None,
    sort_by: str = "cheapest",
    limit: int = 5,
) -> dict:
    """Find direct flights from ``origin`` to ``destination``.

    If ``date`` (YYYY-MM-DD) is given and the dataset has flights that day they
    are preferred; otherwise all flights on the route are returned and
    ``date_matched`` is False (the sample dataset has only a few flights/route).
    """
    origin_city, destination_city = resolve_city(origin), resolve_city(destination)
    if origin_city is None or destination_city is None:
        return {"error": f"Unknown city in route '{origin}' -> '{destination}'."}
    if origin_city == destination_city:
        return {"error": "Origin and destination must be different."}
    if sort_by not in FLIGHT_SORTS:
        return {"error": f"sort_by must be one of {FLIGHT_SORTS}."}

    route = [f for f in load_flights() if f["from"] == origin_city and f["to"] == destination_city]
    if not route:
        reachable = sorted({f["to"] for f in load_flights() if f["from"] == origin_city})
        return {
            "origin": origin_city,
            "destination": destination_city,
            "count": 0,
            "flights": [],
            "note": "No direct flight on this route in the dataset.",
            "destinations_reachable_from_origin": reachable,
        }

    candidates, date_matched = route, False
    if date:
        same_day = [f for f in route if f["departure_time"].startswith(date)]
        if same_day:
            candidates, date_matched = same_day, True

    sort_keys = {
        "cheapest": lambda f: f["price"],
        "fastest": lambda f: f["duration_minutes"],
        "earliest": lambda f: f["departure_time"][11:],
    }
    flights = sorted((_enrich_flight(f) for f in candidates), key=sort_keys[sort_by])[:limit]
    result = {
        "origin": origin_city,
        "destination": destination_city,
        "sort_by": sort_by,
        "date_matched": date_matched,
        "count": len(flights),
        "flights": flights,
    }
    if date and not date_matched:
        result["note"] = (
            f"No flight on {date} in the sample dataset; showing available flights on this route "
            "(prices and times are indicative)."
        )
    return result


# --------------------------------------------------------------------------- hotels
def recommend_hotels(
    city: str,
    min_stars: int = 0,
    max_price_per_night: int | None = None,
    sort_by: str = "best_value",
    limit: int = 5,
) -> dict:
    """Recommend hotels in ``city`` filtered by star rating and nightly price.

    ``best_value`` ranks by stars per rupee; ``highest_rated`` by stars then
    price; ``cheapest`` by price.
    """
    city_name = resolve_city(city)
    if city_name is None:
        return {"error": f"Unknown city '{city}'."}
    if sort_by not in HOTEL_SORTS:
        return {"error": f"sort_by must be one of {HOTEL_SORTS}."}

    hotels = [
        h
        for h in load_hotels()
        if h["city"] == city_name
        and h["stars"] >= min_stars
        and (max_price_per_night is None or h["price_per_night"] <= max_price_per_night)
    ]
    sort_keys = {
        "best_value": lambda h: -h["stars"] / h["price_per_night"],
        "cheapest": lambda h: h["price_per_night"],
        "highest_rated": lambda h: (-h["stars"], h["price_per_night"]),
    }
    hotels.sort(key=sort_keys[sort_by])
    return {"city": city_name, "sort_by": sort_by, "count": len(hotels[:limit]), "hotels": hotels[:limit]}


# --------------------------------------------------------------------------- places
def discover_places(
    city: str,
    place_type: str | None = None,
    min_rating: float = 0.0,
    limit: int = 10,
) -> dict:
    """List attractions in ``city``, best rated first, optionally filtered by type."""
    city_name = resolve_city(city)
    if city_name is None:
        return {"error": f"Unknown city '{city}'."}

    in_city = [p for p in load_places() if p["city"] == city_name]
    available_types = sorted({p["type"] for p in in_city})
    wanted = place_type.strip().lower() if place_type else None
    places = [
        p
        for p in in_city
        if p["rating"] >= min_rating and (wanted is None or p["type"] == wanted)
    ]
    places.sort(key=lambda p: -p["rating"])
    return {
        "city": city_name,
        "available_types": available_types,
        "count": len(places[:limit]),
        "places": places[:limit],
    }


# --------------------------------------------------------------------------- budget
def estimate_budget(
    flight_cost: float,
    hotel_price_per_night: float,
    nights: int,
    return_flight_cost: float = 0.0,
    daily_expense: float = DEFAULT_DAILY_EXPENSE_INR,
    travelers: int = 1,
) -> dict:
    """Sum flights + hotel + local expenses (INR).

    Flights and daily expenses scale per traveller; one room is booked for every
    two travellers. Trip days = nights + 1.
    """
    if nights < 1 or travelers < 1:
        return {"error": "nights and travelers must be at least 1."}
    days = nights + 1
    rooms = math.ceil(travelers / 2)
    breakdown = {
        "outbound_flight": round(flight_cost * travelers),
        "return_flight": round(return_flight_cost * travelers),
        "hotel": round(hotel_price_per_night * nights * rooms),
        "food_and_local_travel": round(daily_expense * days * travelers),
    }
    return {
        "currency": "INR",
        "travelers": travelers,
        "rooms": rooms,
        "nights": nights,
        "days": days,
        "breakdown": breakdown,
        "total": sum(breakdown.values()),
    }
