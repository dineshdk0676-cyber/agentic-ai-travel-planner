"""LangChain tool-calling agent that plans trips by calling the travel tools."""

import json
import re
from datetime import date

PROVIDERS = {
    "OpenAI": {"default_model": "gpt-4o-mini", "env_key": "OPENAI_API_KEY"},
    "Google Gemini": {"default_model": "gemini-2.0-flash", "env_key": "GOOGLE_API_KEY"},
    "Anthropic": {"default_model": "claude-3-5-haiku-latest", "env_key": "ANTHROPIC_API_KEY"},
}

SYSTEM_PROMPT = """You are an expert AI travel planner for trips within India. Today is {today}.
All prices are in Indian Rupees (INR). You MUST use the tools for every fact; never invent
flights, hotels, attractions, prices or weather.

Work step by step:
1. Call flight_search_tool for the outbound leg, and again with origin/destination swapped for the return leg.
2. Call hotel_recommendation_tool for the destination, honouring the user's star/price preferences.
3. Call places_discovery_tool (optionally per preferred type) for attractions.
4. Call weather_lookup_tool for the destination for the trip dates.
5. Call budget_estimation_tool with the chosen prices. Trip days = nights + 1.
If a tool reports no flight or hotel, say so honestly and continue with what is available.
If the user gave a budget cap and the total exceeds it, pick cheaper options and re-estimate.
Put outdoor places (park, beach, lake, fort, monument) on dry days and indoor ones on rainy days.

Final answer format (Markdown):
## Your N-Day Trip to <City> (<dates>)
### Flights  (outbound + return, airline, price, departure time)
### Hotel  (name, price/night, stars)
### Weather  (day by day)
### Itinerary  (Day 1..N with places, ratings and arrival/departure notes)
### Estimated Budget  (flight, hotel, food & travel, total)
### Why these choices?  (short justification of flight, hotel and places)
### Notes  (data caveats, e.g. flight dates not matching, estimated return fare)
Then finish with ONE fenced ```json block containing: trip_summary, flight, hotel, weather,
itinerary (day, date, weather, activities), budget and reasoning."""


def build_llm(provider: str, api_key: str, model: str | None = None, temperature: float = 0.0):
    """Create the chat model for the chosen provider (imports are lazy)."""
    if not api_key:
        raise ValueError(f"An API key is required for {provider}.")
    model_name = model or PROVIDERS[provider]["default_model"]

    if provider == "OpenAI":
        from langchain_openai import ChatOpenAI

        return ChatOpenAI(model=model_name, api_key=api_key, temperature=temperature)
    if provider == "Google Gemini":
        from langchain_google_genai import ChatGoogleGenerativeAI

        return ChatGoogleGenerativeAI(model=model_name, google_api_key=api_key, temperature=temperature)
    if provider == "Anthropic":
        from langchain_anthropic import ChatAnthropic

        return ChatAnthropic(model=model_name, api_key=api_key, temperature=temperature)
    raise ValueError(f"Unsupported provider: {provider}")


def build_agent_executor(llm):
    """Wire the LLM, tools and prompt into an AgentExecutor."""
    from langchain.agents import AgentExecutor, create_tool_calling_agent
    from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

    from .tools import ALL_TOOLS

    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", SYSTEM_PROMPT.replace("{today}", date.today().isoformat())),
            ("human", "{input}"),
            MessagesPlaceholder("agent_scratchpad"),
        ]
    )
    agent = create_tool_calling_agent(llm, ALL_TOOLS, prompt)
    return AgentExecutor(
        agent=agent,
        tools=ALL_TOOLS,
        max_iterations=15,
        handle_parsing_errors=True,
        return_intermediate_steps=True,
        verbose=False,
    )


def _message_text(output) -> str:
    """Providers such as Gemini/Anthropic may return a list of content blocks."""
    if isinstance(output, str):
        return output
    if isinstance(output, list):
        return "".join(b.get("text", "") if isinstance(b, dict) else str(b) for b in output)
    return str(output)


def extract_json_block(text: str) -> tuple[str, dict | None]:
    """Split the final answer into (markdown, parsed JSON block or None)."""
    match = re.search(r"```json\s*(\{.*?\})\s*```", text, flags=re.DOTALL)
    if not match:
        return text.strip(), None
    try:
        data = json.loads(match.group(1))
    except json.JSONDecodeError:
        return text.strip(), None
    return (text[: match.start()] + text[match.end():]).strip(), data


def run_agent(executor, user_request: str) -> dict:
    """Run the agent and return markdown, parsed JSON and the tool-call trace."""
    result = executor.invoke({"input": user_request})
    markdown, structured = extract_json_block(_message_text(result["output"]))
    steps = [
        {"tool": action.tool, "input": action.tool_input, "output": str(observation)[:1500]}
        for action, observation in result.get("intermediate_steps", [])
    ]
    return {"markdown": markdown, "json": structured, "steps": steps}


def build_user_request(
    origin: str,
    destination: str,
    start_date: date,
    days: int,
    travelers: int,
    min_stars: int,
    flight_sort: str,
    place_types: list[str],
    budget_limit: float | None,
    daily_expense: float,
    extra_notes: str = "",
) -> str:
    """Turn the form inputs into a natural-language request for the agent."""
    parts = [
        f"Plan a {days}-day trip from {origin} to {destination} starting {start_date.isoformat()} "
        f"for {travelers} traveller(s) ({days - 1} nights).",
        f"Prefer the {flight_sort} flight. Hotel must be at least {min_stars} stars.",
        f"Assume food and local travel of INR {daily_expense:,.0f} per person per day.",
    ]
    if place_types:
        parts.append(f"I am interested in these attraction types: {', '.join(place_types)}.")
    if budget_limit:
        parts.append(f"My total budget is INR {budget_limit:,.0f}.")
    if extra_notes.strip():
        parts.append(f"Additional wishes: {extra_notes.strip()}")
    return " ".join(parts)
