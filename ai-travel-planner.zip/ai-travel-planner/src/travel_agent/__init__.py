"""Agentic AI Travel Planning Assistant built with LangChain."""

__version__ = "1.0.0"
