"""Deterministic (no-LLM) trip planner.

It calls the same services the LangChain tools use, so it works without an API
key (handy for demos and tests) and produces the same structured output the
agent is asked to produce: a JSON-friendly dict plus a Markdown rendering.
"""

from collections.abc import Callable
from datetime import date, timedelta

from . import services
from .config import DEFAULT_DAILY_EXPENSE_INR, OUTDOOR_PLACE_TYPES
from .data_loader import resolve_city
from .weather import get_weather

MAX_PLACES_PER_DAY = 3


def _inr(amount: float) -> str:
    return f"₹{amount:,.0f}"


def _assign_places_to_days(places: list[dict], weather_days: list[dict]) -> list[list[dict]]:
    """Spread places over days; outdoor spots go to the driest days, indoor to the wettest."""
    day_count = len(weather_days)
    schedule: list[list[dict]] = [[] for _ in range(day_count)]
    rain = [d.get("precipitation_mm", 0.0) or 0.0 for d in weather_days]

    for place in places:  # already sorted best rating first
        open_days = [i for i in range(day_count) if len(schedule[i]) < MAX_PLACES_PER_DAY]
        if not open_days:
            break
        if place["type"] in OUTDOOR_PLACE_TYPES:
            day = min(open_days, key=lambda i: (len(schedule[i]), rain[i]))
        else:
            day = min(open_days, key=lambda i: (len(schedule[i]), -rain[i]))
        schedule[day].append(place)
    return schedule


def _pick_hotel(city: str, min_stars: int, hotel_sort: str, nightly_cap: int | None) -> dict | None:
    result = services.recommend_hotels(city, min_stars, nightly_cap, hotel_sort)
    hotels = result.get("hotels", [])
    return hotels[0] if hotels else None


def plan_trip(
    origin: str,
    destination: str,
    start_date: date,
    days: int,
    travelers: int = 1,
    flight_sort: str = "cheapest",
    hotel_sort: str = "best_value",
    min_hotel_stars: int = 3,
    place_types: list[str] | None = None,
    daily_expense: float = DEFAULT_DAILY_EXPENSE_INR,
    budget_limit: float | None = None,
    weather_provider: Callable[..., dict] = get_weather,
) -> dict:
    """Build a complete itinerary dict. Raises ``ValueError`` for invalid input."""
    origin_city, destination_city = resolve_city(origin), resolve_city(destination)
    if origin_city is None or destination_city is None:
        raise ValueError("Unknown origin or destination city.")
    if origin_city == destination_city:
        raise ValueError("Origin and destination must be different.")
    if not 2 <= days <= 14:
        raise ValueError("Trip length must be between 2 and 14 days.")

    nights = days - 1
    end_date = start_date + timedelta(days=nights)
    reasoning: list[str] = []
    warnings: list[str] = []

    # ---- flights ------------------------------------------------------------------
    outbound_result = services.search_flights(origin_city, destination_city, start_date.isoformat(), flight_sort)
    return_result = services.search_flights(destination_city, origin_city, end_date.isoformat(), flight_sort)
    outbound = (outbound_result.get("flights") or [None])[0]
    inbound = (return_result.get("flights") or [None])[0]

    if outbound is None:
        warnings.append(
            f"No direct flight {origin_city} → {destination_city} in the dataset; flight cost is excluded."
        )
    else:
        reasoning.append(
            f"Outbound: {outbound['airline']} chosen as the {flight_sort} of "
            f"{outbound_result['count']} option(s) on {origin_city} → {destination_city}."
        )
        if outbound_result.get("note"):
            warnings.append(outbound_result["note"])
    if inbound is None:
        warnings.append(f"No direct return flight {destination_city} → {origin_city} in the dataset.")
        if outbound is not None:
            warnings.append("Return flight cost is assumed equal to the outbound fare (estimate).")
    elif return_result.get("note"):
        warnings.append(return_result["note"].replace("this route", "the return route"))

    outbound_price = outbound["price"] if outbound else 0
    if inbound:
        return_price, return_estimated = inbound["price"], False
    else:
        return_price, return_estimated = (outbound_price if outbound else 0), outbound is not None

    # ---- weather ------------------------------------------------------------------
    weather = weather_provider(destination_city, start_date, end_date)
    weather_days = weather.get("days") or [
        {"date": (start_date + timedelta(days=i)).isoformat(), "summary": "Unavailable"} for i in range(days)
    ]
    if weather.get("error"):
        warnings.append(weather["error"])
    elif weather.get("note"):
        reasoning.append(f"Weather: {weather['note']}")

    # ---- hotel (with a fallback to cheaper options if the budget is exceeded) -------
    hotel = _pick_hotel(destination_city, min_hotel_stars, hotel_sort, None)
    if hotel is None:
        hotel = _pick_hotel(destination_city, 0, hotel_sort, None)
        if hotel:
            warnings.append(f"No hotel with ≥{min_hotel_stars}★ in {destination_city}; relaxed the star filter.")
    if hotel is None:
        raise ValueError(f"No hotels available in {destination_city}.")

    def build_budget(chosen_hotel: dict) -> dict:
        return services.estimate_budget(
            outbound_price, chosen_hotel["price_per_night"], nights, return_price, daily_expense, travelers
        )

    budget = build_budget(hotel)
    if budget_limit and budget["total"] > budget_limit:
        cheaper = _pick_hotel(destination_city, 0, "cheapest", None)
        if cheaper and cheaper["hotel_id"] != hotel["hotel_id"]:
            reasoning.append(
                f"Total {_inr(budget['total'])} exceeded your budget of {_inr(budget_limit)}, "
                f"so the cheapest hotel ({cheaper['name']}) was chosen instead."
            )
            hotel, budget = cheaper, build_budget(cheaper)
        if budget["total"] > budget_limit:
            warnings.append(
                f"Estimated total {_inr(budget['total'])} is still above your budget of {_inr(budget_limit)}."
            )
    reasoning.append(
        f"Hotel: {hotel['name']} ({hotel['stars']}★, {_inr(hotel['price_per_night'])}/night) "
        f"ranked first by '{hotel_sort}' in {destination_city}."
    )

    # ---- places & day-wise itinerary ------------------------------------------------
    wanted_types = [t.lower() for t in place_types] if place_types else [None]
    places: list[dict] = []
    for place_type in wanted_types:
        places.extend(services.discover_places(destination_city, place_type, limit=20)["places"])
    seen, unique_places = set(), []
    for place in sorted(places, key=lambda p: -p["rating"]):
        if place["place_id"] not in seen:
            seen.add(place["place_id"])
            unique_places.append(place)
    if place_types and not unique_places:
        warnings.append("No attractions matched the selected types; showing all attractions instead.")
        unique_places = services.discover_places(destination_city, limit=20)["places"]

    schedule = _assign_places_to_days(unique_places, weather_days)
    itinerary = []
    for index in range(days):
        day_date = start_date + timedelta(days=index)
        notes = []
        if index == 0:
            notes.append(
                f"Arrive from {origin_city}"
                + (f" (flight lands {outbound['arrival_time'][11:16]})" if outbound else "")
                + "; check in to the hotel."
            )
        if index == days - 1:
            notes.append(f"Check out and head back to {origin_city}.")
        if not schedule[index]:
            notes.append("Free time: local food, shopping and relaxing.")
        itinerary.append(
            {
                "day": index + 1,
                "date": day_date.isoformat(),
                "weather": weather_days[index] if index < len(weather_days) else {"summary": "Unavailable"},
                "activities": [
                    {"name": p["name"], "type": p["type"], "rating": p["rating"]} for p in schedule[index]
                ],
                "notes": notes,
            }
        )
    reasoning.append(
        "Attractions ranked by rating; open-air spots are scheduled on the driest days and indoor ones on wetter days."
    )

    plan = {
        "trip_summary": {
            "title": f"Your {days}-Day Trip to {destination_city}",
            "origin": origin_city,
            "destination": destination_city,
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "days": days,
            "nights": nights,
            "travelers": travelers,
        },
        "flight": {"outbound": outbound, "return": inbound, "return_estimated": return_estimated},
        "hotel": hotel,
        "weather": {"source": weather.get("source"), "note": weather.get("note")},
        "itinerary": itinerary,
        "budget": {**budget, "limit": budget_limit},
        "reasoning": reasoning,
        "warnings": warnings,
    }
    return plan


def _flight_line(label: str, flight: dict | None, estimated: bool = False) -> str:
    if flight is None:
        return f"- {label}: not available in dataset"
    suffix = " (estimated fare)" if estimated else ""
    return (
        f"- {label}: {flight['airline']} ({_inr(flight['price'])}) – departs "
        f"{flight['from']} at {flight['departure_time'][11:16]}, {flight['duration_hours']} h{suffix}"
    )


def render_markdown(plan: dict) -> str:
    """Render a plan dict in the layout from the project brief."""
    summary, budget, hotel = plan["trip_summary"], plan["budget"], plan["hotel"]
    start = date.fromisoformat(summary["start_date"])
    end = date.fromisoformat(summary["end_date"])
    lines = [
        f"## {summary['title']} ({start:%b} {start.day}–{end.day if start.month == end.month else end.strftime('%b %d')})",
        f"*{summary['origin']} → {summary['destination']} · {summary['travelers']} traveller(s)*",
        "",
        "### ✈️ Flights",
        _flight_line("Outbound", plan["flight"]["outbound"]),
        _flight_line("Return", plan["flight"]["return"], plan["flight"]["return_estimated"]),
        "",
        "### 🏨 Hotel",
        f"- {hotel['name']} ({_inr(hotel['price_per_night'])}/night, {hotel['stars']}-star)",
        f"- Amenities: {', '.join(hotel['amenities'])}",
        "",
        "### 🌦️ Weather",
    ]
    for day in plan["itinerary"]:
        w = day["weather"]
        temp = f" ({w['temp_min_c']:.0f}–{w['temp_max_c']:.0f}°C)" if "temp_max_c" in w else ""
        lines.append(f"- Day {day['day']}: {w['summary']}{temp}")
    if plan["weather"].get("note"):
        lines.append(f"- _{plan['weather']['note']}_")

    lines += ["", "### 🗺️ Itinerary"]
    for day in plan["itinerary"]:
        spots = ", ".join(f"{a['name']} ({a['type']}, ⭐{a['rating']})" for a in day["activities"])
        lines.append(f"**Day {day['day']} – {day['date']}:** {spots or 'Leisure day'}")
        lines.extend(f"  - {note}" for note in day["notes"])

    b = budget["breakdown"]
    lines += [
        "",
        "### 💰 Estimated Budget",
        f"- Flights: {_inr(b['outbound_flight'] + b['return_flight'])}",
        f"- Hotel ({budget['nights']} nights × {budget['rooms']} room): {_inr(b['hotel'])}",
        f"- Food & local travel: {_inr(b['food_and_local_travel'])}",
        "-------------------------------------",
        f"**Total Cost: {_inr(budget['total'])}**",
    ]
    if budget.get("limit"):
        lines.append(f"(Budget limit: {_inr(budget['limit'])})")

    if plan["reasoning"]:
        lines += ["", "### 🧠 Why these choices?"] + [f"- {r}" for r in plan["reasoning"]]
    if plan["warnings"]:
        lines += ["", "### ⚠️ Notes"] + [f"- {w}" for w in plan["warnings"]]
    return "\n".join(lines)
