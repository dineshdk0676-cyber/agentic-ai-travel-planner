"""Weather lookup using the free Open-Meteo API (no API key required).

* Dates within the next ~15 days use the live forecast endpoint.
* Dates further away (or in the past) fall back to the same calendar dates one
  year earlier from the archive endpoint, clearly labelled as ``historical``.
"""

from datetime import date, datetime, timedelta

import requests

from .config import (
    CITY_COORDINATES,
    FORECAST_HORIZON_DAYS,
    REQUEST_TIMEOUT_SECONDS,
    WMO_WEATHER_CODES,
)
from .data_loader import resolve_city

FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"
DAILY_FIELDS = "weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum"


def _parse_date(value: str | date) -> date:
    """Accept a ``date`` or an ISO ``YYYY-MM-DD`` string."""
    if isinstance(value, date):
        return value
    return datetime.strptime(value, "%Y-%m-%d").date()


def _describe(code: int | None) -> str:
    return WMO_WEATHER_CODES.get(int(code), "Unknown") if code is not None else "Unknown"


def _fetch(url: str, latitude: float, longitude: float, start: date, end: date) -> dict:
    """Call Open-Meteo and return the ``daily`` block. Raises on HTTP / network errors."""
    params = {
        "latitude": latitude,
        "longitude": longitude,
        "daily": DAILY_FIELDS,
        "timezone": "auto",
        "start_date": start.isoformat(),
        "end_date": end.isoformat(),
    }
    response = requests.get(url, params=params, timeout=REQUEST_TIMEOUT_SECONDS)
    response.raise_for_status()
    return response.json()["daily"]


def get_weather(city: str, start_date: str | date, end_date: str | date) -> dict:
    """Return day-wise weather for ``city`` between two dates (inclusive).

    Result keys: ``city``, ``source`` (forecast | historical | unavailable),
    ``days`` (list of dicts) and optionally ``error`` / ``note``.
    """
    canonical = resolve_city(city)
    if canonical is None:
        return {"error": f"Unknown city '{city}'.", "days": []}

    try:
        start, end = _parse_date(start_date), _parse_date(end_date)
    except ValueError:
        return {"error": "Dates must be in YYYY-MM-DD format.", "days": []}
    if end < start:
        return {"error": "end_date must not be before start_date.", "days": []}

    latitude, longitude = CITY_COORDINATES[canonical]
    today = date.today()
    use_forecast = today <= start and end <= today + timedelta(days=FORECAST_HORIZON_DAYS)

    if use_forecast:
        source, url = "forecast", FORECAST_URL
        query_start, query_end = start, end
        note = "Live forecast from Open-Meteo."
    else:
        # Same dates last year (365 days back keeps weekday alignment irrelevant here).
        shift = timedelta(days=365)
        source, url = "historical", ARCHIVE_URL
        query_start, query_end = start - shift, end - shift
        # Make sure we never ask the archive for dates that are too recent.
        if query_end > today - timedelta(days=7):
            query_start -= shift
            query_end -= shift
        note = (
            "Trip dates are beyond the 16-day forecast window, so these are typical "
            f"conditions from {query_start.isoformat()} to {query_end.isoformat()}."
        )

    try:
        daily = _fetch(url, latitude, longitude, query_start, query_end)
    except (requests.RequestException, KeyError, ValueError) as exc:
        return {
            "city": canonical,
            "source": "unavailable",
            "error": f"Weather service unavailable: {exc}",
            "days": [
                {"date": (start + timedelta(days=i)).isoformat(), "summary": "Unavailable"}
                for i in range((end - start).days + 1)
            ],
        }

    days = []
    for offset, _ in enumerate(daily["time"]):
        days.append(
            {
                "date": (start + timedelta(days=offset)).isoformat(),
                "summary": _describe(daily["weather_code"][offset]),
                "temp_max_c": daily["temperature_2m_max"][offset],
                "temp_min_c": daily["temperature_2m_min"][offset],
                "precipitation_mm": daily["precipitation_sum"][offset] or 0.0,
            }
        )
    return {"city": canonical, "source": source, "note": note, "days": days}
