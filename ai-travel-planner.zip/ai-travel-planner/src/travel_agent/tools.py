"""LangChain tools that wrap the services so an LLM agent can call them."""

import json
from typing import Optional

from langchain_core.tools import tool

from . import services
from .config import DEFAULT_DAILY_EXPENSE_INR
from .weather import get_weather


def _to_json(payload: dict) -> str:
    """Tools return JSON strings: easy for the LLM to read, easy for us to log."""
    return json.dumps(payload, ensure_ascii=False)


@tool
def flight_search_tool(
    origin: str, destination: str, date: Optional[str] = None, sort_by: str = "cheapest"
) -> str:
    """Search direct flights between two Indian cities from the flights dataset.

    Args:
        origin: Departure city, e.g. "Delhi".
        destination: Arrival city, e.g. "Goa".
        date: Optional travel date in YYYY-MM-DD format.
        sort_by: "cheapest", "fastest" or "earliest".
    Returns JSON with matching flights (airline, times, price in INR, duration).
    For a return journey call this tool again with origin/destination swapped.
    """
    try:
        return _to_json(services.search_flights(origin, destination, date, sort_by))
    except Exception as exc:  # noqa: BLE001 - tools must never crash the agent loop
        return _to_json({"error": f"flight search failed: {exc}"})


@tool
def hotel_recommendation_tool(
    city: str,
    min_stars: int = 0,
    max_price_per_night: Optional[int] = None,
    sort_by: str = "best_value",
) -> str:
    """Recommend hotels in a city from the hotels dataset.

    Args:
        city: City name, e.g. "Goa".
        min_stars: Minimum star rating (1-5).
        max_price_per_night: Optional price cap in INR per night.
        sort_by: "best_value", "cheapest" or "highest_rated".
    Returns JSON with hotels (name, stars, price_per_night, amenities).
    """
    try:
        return _to_json(services.recommend_hotels(city, min_stars, max_price_per_night, sort_by))
    except Exception as exc:  # noqa: BLE001
        return _to_json({"error": f"hotel search failed: {exc}"})


@tool
def places_discovery_tool(
    city: str, place_type: Optional[str] = None, min_rating: float = 0.0
) -> str:
    """Find tourist attractions in a city from the places dataset, best rated first.

    Args:
        city: City name, e.g. "Jaipur".
        place_type: Optional filter such as park, beach, fort, temple, museum, lake, market, monument.
        min_rating: Minimum rating (0-5).
    Returns JSON with places (name, type, rating) and the list of available types.
    """
    try:
        return _to_json(services.discover_places(city, place_type, min_rating))
    except Exception as exc:  # noqa: BLE001
        return _to_json({"error": f"places search failed: {exc}"})


@tool
def weather_lookup_tool(city: str, start_date: str, end_date: str) -> str:
    """Get day-wise weather for a city using the free Open-Meteo API.

    Args:
        city: City name.
        start_date: First day, YYYY-MM-DD.
        end_date: Last day, YYYY-MM-DD.
    Returns JSON with per-day summary, max/min temperature (C) and rain (mm).
    The `source` field says whether this is a live forecast or historical typical weather.
    """
    try:
        return _to_json(get_weather(city, start_date, end_date))
    except Exception as exc:  # noqa: BLE001
        return _to_json({"error": f"weather lookup failed: {exc}"})


@tool
def budget_estimation_tool(
    flight_cost: float,
    hotel_price_per_night: float,
    nights: int,
    return_flight_cost: float = 0.0,
    daily_expense: float = DEFAULT_DAILY_EXPENSE_INR,
    travelers: int = 1,
) -> str:
    """Estimate total trip cost in INR = flights + hotel + food/local travel.

    Args:
        flight_cost: Outbound flight price per traveller.
        hotel_price_per_night: Hotel price per room per night.
        nights: Number of nights (trip days = nights + 1).
        return_flight_cost: Return flight price per traveller (0 if none).
        daily_expense: Food and local transport per person per day.
        travelers: Number of travellers (one room per two travellers).
    """
    try:
        return _to_json(
            services.estimate_budget(
                flight_cost, hotel_price_per_night, nights, return_flight_cost, daily_expense, travelers
            )
        )
    except Exception as exc:  # noqa: BLE001
        return _to_json({"error": f"budget estimation failed: {exc}"})


ALL_TOOLS = [
    flight_search_tool,
    hotel_recommendation_tool,
    places_discovery_tool,
    weather_lookup_tool,
    budget_estimation_tool,
]
