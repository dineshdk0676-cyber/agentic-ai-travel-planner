"""Unit tests for services and the offline planner (no network, no LLM)."""

import sys
from datetime import date
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from travel_agent import services  # noqa: E402
from travel_agent.agent import extract_json_block  # noqa: E402
from travel_agent.planner import plan_trip, render_markdown  # noqa: E402


def fake_weather(city, start, end):
    """Deterministic stand-in for the Open-Meteo call."""
    from datetime import timedelta

    count = (end - start).days + 1
    return {
        "city": city,
        "source": "forecast",
        "note": "test weather",
        "days": [
            {
                "date": (start + timedelta(days=i)).isoformat(),
                "summary": "Sunny" if i % 2 == 0 else "Rain",
                "temp_max_c": 30.0,
                "temp_min_c": 24.0,
                "precipitation_mm": 0.0 if i % 2 == 0 else 12.0,
            }
            for i in range(count)
        ],
    }


def test_flights_cheapest_and_fastest():
    cheapest = services.search_flights("Hyderabad", "Kolkata", sort_by="cheapest")
    assert cheapest["count"] == 1 and cheapest["flights"][0]["flight_id"] == "FL0015"
    assert cheapest["flights"][0]["duration_hours"] == 2.0

    two = services.search_flights("Bangalore", "Delhi", sort_by="cheapest")
    assert [f["price"] for f in two["flights"]] == sorted(f["price"] for f in two["flights"])
    fastest = services.search_flights("Bangalore", "Delhi", sort_by="fastest")
    assert fastest["flights"][0]["duration_minutes"] <= fastest["flights"][-1]["duration_minutes"]


def test_flight_unknown_route_and_city():
    assert services.search_flights("Delhi", "Goa")["count"] == 0
    assert "error" in services.search_flights("Atlantis", "Goa")
    assert "error" in services.search_flights("Goa", "goa")


def test_flight_city_aliases_and_date_match():
    result = services.search_flights("bengaluru", "delhi", date="2025-01-25")
    assert result["date_matched"] and result["flights"][0]["flight_id"] == "FL0009"


def test_hotels_filters_and_sorting():
    result = services.recommend_hotels("Goa", min_stars=4, sort_by="cheapest")
    assert all(h["stars"] >= 4 for h in result["hotels"])
    prices = [h["price_per_night"] for h in result["hotels"]]
    assert prices == sorted(prices)
    assert services.recommend_hotels("Goa", max_price_per_night=1)["count"] == 0


def test_places_filter():
    result = services.discover_places("Kolkata", min_rating=4.9)
    assert result["count"] == 3 and all(p["rating"] >= 4.9 for p in result["places"])
    assert all(p["type"] == "temple" for p in services.discover_places("Kolkata", "temple")["places"])


def test_budget_matches_brief_example():
    budget = services.estimate_budget(4800, 3200, nights=2, return_flight_cost=0, daily_expense=2500 / 3)
    assert budget["breakdown"]["hotel"] == 6400
    assert budget["total"] == 4800 + 6400 + 2500


def test_budget_scales_with_travelers():
    budget = services.estimate_budget(1000, 2000, nights=2, return_flight_cost=1000, daily_expense=500, travelers=3)
    assert budget["rooms"] == 2
    assert budget["total"] == 3000 + 3000 + 8000 + 4500


def test_plan_trip_structure_and_total():
    plan = plan_trip("Hyderabad", "Goa", date(2026, 12, 1), 3, weather_provider=fake_weather)
    assert len(plan["itinerary"]) == 3
    assert plan["budget"]["total"] == sum(plan["budget"]["breakdown"].values())
    assert plan["flight"]["outbound"]["to"] == "Goa"
    assert "Total Cost" in render_markdown(plan)


def test_plan_trip_outdoor_places_prefer_dry_days():
    plan = plan_trip("Hyderabad", "Goa", date(2026, 12, 1), 3, weather_provider=fake_weather)
    rainy = plan["itinerary"][1]  # day 2 is rainy in the fake data
    assert all(a["type"] not in {"park", "beach", "lake", "fort", "monument"} for a in rainy["activities"][:1])


def test_plan_trip_missing_route_warns_but_succeeds():
    plan = plan_trip("Delhi", "Goa", date(2026, 12, 1), 3, weather_provider=fake_weather)
    assert plan["flight"]["outbound"] is None
    assert any("No direct flight" in w for w in plan["warnings"])


def test_plan_trip_budget_cap_switches_to_cheaper_hotel():
    expensive = plan_trip("Hyderabad", "Delhi", date(2026, 12, 1), 3, min_hotel_stars=4,
                          hotel_sort="highest_rated", weather_provider=fake_weather)
    capped = plan_trip("Hyderabad", "Delhi", date(2026, 12, 1), 3, min_hotel_stars=4,
                       hotel_sort="highest_rated", budget_limit=1, weather_provider=fake_weather)
    assert capped["hotel"]["price_per_night"] <= expensive["hotel"]["price_per_night"]
    assert any("still above" in w for w in capped["warnings"])


def test_plan_trip_validation():
    with pytest.raises(ValueError):
        plan_trip("Delhi", "Delhi", date(2026, 12, 1), 3, weather_provider=fake_weather)
    with pytest.raises(ValueError):
        plan_trip("Delhi", "Goa", date(2026, 12, 1), 30, weather_provider=fake_weather)


def test_plan_trip_survives_weather_failure():
    def broken(city, start, end):
        return {"error": "boom", "days": []}

    plan = plan_trip("Hyderabad", "Goa", date(2026, 12, 1), 3, weather_provider=broken)
    assert plan["itinerary"][0]["weather"]["summary"] == "Unavailable"
    assert "boom" in plan["warnings"]


def test_extract_json_block():
    text = 'Hello\n```json\n{"a": 1}\n```'
    markdown, data = extract_json_block(text)
    assert markdown == "Hello" and data == {"a": 1}
    assert extract_json_block("no json here")[1] is None
